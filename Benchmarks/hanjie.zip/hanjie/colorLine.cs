using System;
using System.Collections.Generic;
using System.Text;

namespace hanjie
{
	public class colorLine
	{
		public colorLine prevLine = null; // precalc
		public colorLine nextLine = null; // precalc
		public int color = 0;
		public int actualPos = 0;
		public int count = 0;
		public int absoluteMin = 0;
		public int absoluteMax = 0;
		public bool spaceBefore; // precalc - depending if same as previous color
		public bool spaceAfter; // precalc - depending if same as next color
		public bool mLineDone = false;
		public int mFixRange;
		public colorRow mRow = null;
		
		
		public int posMin()
		{
			if (mLineDone) return actualPos;
			int pos;
			if (prevLine != null) pos = prevLine.posMin() + prevLine.count + (spaceBefore ? 1 : 0);
			else pos = 0;
			while (pos <= absoluteMax && canGo(pos) == false) pos++;
			if (pos>absoluteMax) return -1;
			else return pos;
		}
		
		public int posMax()
		{
			if (mLineDone) return actualPos;
			int pos;
			if (nextLine != null) pos = nextLine.posMax() - count - (spaceAfter ? 1 : 0);
			else pos = mRow.mRowLength - count;
			while (pos >= absoluteMin && canGo(pos) == false) pos--;
			if (pos < absoluteMin) return -1;
			else return pos;
		}

		public bool canGo(int pos)
		{
			if (pos < absoluteMin || pos > absoluteMax) return false;
			if (spaceBefore && mRow.mCells[pos - 1].color > 0) return false;
			int rlen = mRow.mRowLength;
			
			if (prevLine == null) 
			{
				for (int j = 0; j < pos; j++) if (mRow.mCells[j].color > 0) return false;
			}
			else if (prevLine.mLineDone)
			{
				for (int j=prevLine.actualPos + prevLine.count; j < pos; j++) 
					if (mRow.mCells[j].color > 0) return false;
			}

			for (int j = pos + this.count - 1; j >= pos; j--)
			{
				int c = mRow.mCells[j].color;
				if (c >= 0 && c != color) return false;
			}
			if (spaceAfter && mRow.mCells[pos + this.count].color > 0) return false;

			if (nextLine == null)
			{
				for (int j =(pos+count); j < mRow.mRowLength; j++) if (mRow.mCells[j].color > 0) return false;
			}
			else if (nextLine.mLineDone)
			{
				for (int j = pos + count; j < nextLine.actualPos; j++)
					if (mRow.mCells[j].color > 0) return false;
			}

			return true;
		}


		public colorLine(colorRow Row, Cell c)
		{
			mRow = Row;
			color = c.color;
			count = c.count;
		}

	
	}
}
