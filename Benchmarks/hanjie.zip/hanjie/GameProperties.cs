using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace hanjie
{
	public partial class GameProperties : Form
	{
		public HanjieBoard HanjieBoard;

		public GameProperties()
		{
			InitializeComponent();
		}

		private void GameProperties_Load(object sender, EventArgs e)
		{
			saveFixedCols  = HanjieBoard.fixedCols;
			saveSize = HanjieBoard.BoardSize;
			saveNbColors = HanjieBoard.NbColors;
			showSaved();
		}

		Size saveSize;
		int saveFixedCols;
		int saveNbColors;

		private void udWidth_ValueChanged(object sender, EventArgs e)
		{
			updateSize();
		}

		private void udHeight_ValueChanged(object sender, EventArgs e)
		{
			updateSize();
		}

		private void udClues_ValueChanged(object sender, EventArgs e)
		{
			updateSize();
		}

		private void udColors_ValueChanged(object sender, EventArgs e)
		{
			updateSize();
		}

		void updateSize()
		{
			HanjieBoard.fixedCols = (int)udClues.Value;
			HanjieBoard.fixedRows = (int)udClues.Value;
			HanjieBoard.BoardSize = new Size((int)udWidth.Value, (int)udHeight.Value);
			HanjieBoard.NbColors = (int)udColors.Value;
		}

		void showSaved()
		{
			udClues.Value = saveFixedCols;
			udWidth.Value = saveSize.Width;
			udHeight.Value = saveSize.Height;
			udColors.Value = saveNbColors;
		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			showSaved();
		}

	}
}