using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace hanjie
{
	public partial class Form1 : Form
	{
		private vbAccelerator.Components.Controls.PopupWindowHelper popupHelper = null;
		ColorSelection colorSelection;
		Cell SelectedCell;
		System.Threading.Thread resolveThread;
		protected static internal Form1 instance;

		public Form1()
		{
			instance = this;
			InitializeComponent();
		}

		protected override void OnHandleCreated(EventArgs e)
		{
			popupHelper = new vbAccelerator.Components.Controls.PopupWindowHelper();
			popupHelper.AssignHandle(this.Handle);
		}

		private void toolStripMenuItem2_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void fitToolStripMenuItem_Click(object sender, EventArgs e)
		{
			HanjieBoard1.Dock = DockStyle.Fill;
		}

		private void smallToolStripMenuItem_Click(object sender, EventArgs e)
		{
			HanjieBoard1.Dock = DockStyle.None;
			HanjieBoard1.SetZoom(8);
		}

		private void normalToolStripMenuItem_Click(object sender, EventArgs e)
		{
			HanjieBoard1.Dock = DockStyle.None;
			HanjieBoard1.SetZoom(16);
		}

		private void largeToolStripMenuItem_Click(object sender, EventArgs e)
		{
			HanjieBoard1.Dock = DockStyle.None;
			HanjieBoard1.SetZoom(32);
		}

		private void showPopup(cellClickedEventArgs e)
		{
			if (e.cell == null) return;

			Point location = HanjieBoard1.PointToScreen(e.cell.Location());
			Double z = HanjieBoard1.zoom;
			location.X = location.X + (int)(z / 2.0);
			location.Y += (int)(z / 2.0);
			SelectedCell = e.cell;			
			if (colorSelection!=null)
			{
				colorSelection.Closed -= new System.EventHandler(this.onColorSelectionClosed);
				colorSelection.Dispose();
			}
			int max;
			if (HanjieBoard1.BoardSize.Width > HanjieBoard1.BoardSize.Height)
				max = HanjieBoard1.BoardSize.Width;
			else
				max = HanjieBoard1.BoardSize.Height;
			colorSelection = new ColorSelection(HanjieBoard1.NbColors, max);
			colorSelection.Closed += new System.EventHandler(this.onColorSelectionClosed);
			popupHelper.ShowPopup(this, colorSelection, location);
		}

		private void HanjieBoard1_cellClicked(object sender, cellClickedEventArgs e)
		{
			showPopup(e);
		}

		private void onColorSelectionClosed(object sender, EventArgs e)
		{
			if (SelectedCell != null)
			{
				if (colorSelection.SelectedCell != null)
				{
					SelectedCell.color = colorSelection.SelectedCell.color;
					SelectedCell.count = colorSelection.SelectedCell.count;
				}
				SelectedCell = null;
				HanjieBoard1.Refresh();
			}
		}

		private void saveToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (saveFileDialog1.FileName.Length > 0)
			{
				SaveFile(saveFileDialog1.FileName);
			}
			else
			{
				saveasToolStripMenuItem_Click(sender,e);
			}
		}

		private void saveasToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (saveFileDialog1.ShowDialog() == DialogResult.OK)
			{
				SaveFile(saveFileDialog1.FileName);
			}
		}

		private void SaveFile(string fullPath)
		{
			using (Stream stream = new FileStream(fullPath, FileMode.Create, FileAccess.Write, FileShare.None))
			{
				// beware Stream stream = File.OpenWrite(fullPath) will leave garbage at the end of the file
				HanjieBoard1.SaveTo(stream);
			}			
		}

		private void x1ToolStripMenuItem_Click(object sender, EventArgs e)
		{
			GameProperties gp = new GameProperties();
			gp.HanjieBoard = HanjieBoard1;
			gp.ShowDialog(this);
		}

		private void loadToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (openFileDialog1.ShowDialog() == DialogResult.OK)
			{
				LoadFile(openFileDialog1.FileName);
			}
		}

		private void searchsolutionToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Resolve();
		}

		private void Form1_Load(object sender, EventArgs e)
		{
			System.IO.FileInfo fi = new FileInfo(Application.ExecutablePath);
			LoadFile(fi.DirectoryName + "\\painter.hnj");
		}

		private void LoadFile(string filename)
		{
			System.IO.FileInfo fi = new FileInfo(filename);
			if (fi.Exists)
			{
				using (Stream stream = File.OpenRead(filename))
				{
					HanjieBoard1.LoadFrom(stream);
				}
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			Resolve();
		}

		void Resolve()
		{
			if (btnResolve.Enabled)
			{
				btnResolve.Enabled = false;
				// I put the intelligent part in another class
				timer1.Enabled = true;
				Brain b = new Brain(HanjieBoard1);				
				resolveThread = new System.Threading.Thread(b.Resolve);
				resolveThread.Start();				
			}
		}

		public void Completed()
		{
			timer1.Enabled = false;
			btnResolve.Enabled = true;
			resolveThread = null;
			HanjieBoard1.Invalidate();
		}

		private void timer1_Tick(object sender, EventArgs e)
		{
			HanjieBoard1.Invalidate();
		}

		private void Form1_FormClosed(object sender, FormClosedEventArgs e)
		{
			if (resolveThread!=null) resolveThread.Abort(); 
		}
	}
}