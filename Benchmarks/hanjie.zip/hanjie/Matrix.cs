using System;
using System.Collections.Generic;
using System.Drawing;
using System.ComponentModel;
using System.Xml;
using System.Xml.Serialization;
using System.Runtime.Serialization;

namespace hanjie
{
	public enum MatrixLocation
	{
		outside,
		fixedRows,
		fixedCols,
		mainCells
	}

	public class Matrix
	{
		protected internal HanjieBoard mHanjieBoard;
		private Size mSize;
		private Cell[,] mCells = new Cell[0, 0];
		private PointF mOrg;
		private MatrixLocation mMatrixLocation;
		private Size mRedLinesModulo;


		public HanjieBoard HanjieBoard
		{
			get
			{
				return mHanjieBoard;
			}
		}

		public Matrix(MatrixLocation matrixLocation, HanjieBoard hanjieBoard)
		{
			mHanjieBoard = hanjieBoard;
			mMatrixLocation = matrixLocation;
			mRedLinesModulo = new Size(5, 5);
		}

		public Size Size
		{
			get
			{
				return mSize;
			}
			set
			{
				ResizeArray(value.Width, value.Height);
			}
		}

		private void ResizeArray(int newWidth, int newHeight)
		{
			if (mSize.Width == newWidth && mSize.Height == newHeight) return;

			Cell[,] newCells = new Cell[newWidth, newHeight];

			for (int x = 0; x < newWidth; x++)
			{
				for (int y = 0; y < newHeight; y++)
				{
					if (x < mSize.Width && y < mSize.Height) newCells[x, y] = mCells[x, y];
					else newCells[x, y] = new Cell(this, x, y);
				}
			}
			mCells = newCells;
			mSize = new Size(newWidth, newHeight);
			if (mHanjieBoard != null) mHanjieBoard.NeedRecalculateZoom(true);
		}

		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden), XmlIgnore()]
		public PointF Org
		{
			get
			{
				return mOrg;
			}
			set
			{
				if (!mOrg.Equals(value))
				{
					mOrg = value;
				}
			}
		}

		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden), XmlIgnore()]
		public int Width
		{
			get
			{
				return mSize.Width;
			}
			set
			{
				if (value != mSize.Width)
				{
					ResizeArray(value, mSize.Height);
				}
			}
		}

		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden), XmlIgnore()]
		public int Height
		{
			get
			{
				return mSize.Height;
			}
			set
			{
				if (value != mSize.Height)
				{
					ResizeArray(mSize.Width, value);
				}
			}
		}

		public void PaintBackGround(Graphics g)
		{
			Single lZoom = mHanjieBoard.zoom;
			Font font = new Font(mHanjieBoard.Font.FontFamily,(float)(lZoom *0.8),GraphicsUnit.Pixel );
			RectangleF r = new RectangleF(0, mOrg.Y, lZoom, lZoom);
			PointF l = new PointF();
			
			for (int y = 0; y < Height; y++)
			{
				r.X = mOrg.X;
				for (int x = 0; x < Width; x++)
				{
					Cell c = mCells[x, y];
					g.FillRectangle(new SolidBrush(c.realColor), r);
					
					int v = c.count;
					l.X = r.X + 1;
					l.Y = r.Y + 1;
					if (v > 0)
					{
						if (c.color == 1)
							g.DrawString(v.ToString(), font, Brushes.White, l);
						else
							g.DrawString(v.ToString(), font, Brushes.Black, l);
					}

					r.X += lZoom;
				}
				r.Y += lZoom;
			}

			int mx, my;
			mx = mRedLinesModulo.Width; if (mx == 0) mx = mSize.Width;
			my = mRedLinesModulo.Height; if (my == 0) my = mSize.Height;

			// draw horizontals
			PointF pt1 = mOrg;
			PointF pt2 = new PointF(mOrg.X + mSize.Width * lZoom, mOrg.Y);
			Pen pen;
			for (int y = 0; y <= mSize.Height; y++)
			{
				if ((y % my) == 0) pen = Pens.Red;
				else pen = Pens.Black;
				g.DrawLine(pen, pt1, pt2);
				pt1.Y += lZoom;
				pt2.Y = pt1.Y;
			}
			// draw verticals
			pt1 = new PointF(mOrg.X, mOrg.Y);
			pt2 = new PointF(mOrg.X, mOrg.Y + mSize.Height * lZoom);
			for (int x = 0; x <= mSize.Width; x++)
			{
				if ((x % mx) == 0) pen = Pens.Red;
				else pen = Pens.Black;
				g.DrawLine(pen, pt1, pt2);
				pt1.X += lZoom;
				pt2.X = pt1.X;
			}
		}

		public Cell PointToCell(Point pt)
		{
			Single lZoom = mHanjieBoard.zoom;
			// I uses math.Floor because
			// (int)Math.Floor(-0.1) returns -1
			// whereas (int)(-0.1) returns 0
			int x = (int)Math.Floor((pt.X - mOrg.X) / lZoom);
			int y = (int)Math.Floor((pt.Y - mOrg.Y) / lZoom);
			if (x >= 0 && x < Width && y >= 0 && y < Height)
			{
				return mCells[x, y];
			}
			else return null;
		}

		public Cell GetCell(int x, int y)
		{
			if (x < 0 || y < 0) return null;
			if (x >= mCells.GetLength(0) || y >= mCells.GetLength(1)) return null;
			else return mCells[x, y];
		}

		public Matrix()
		{
			// used by serializer
		}

		public void FixAfterDeserialization()
		{
			for (int y = 0; y < mSize.Height; y++)
			{
				for (int x = 0; x < mSize.Width; x++)
				{
					Cell c = mCells[x, y];
					c.mMatrix = this;
					c.mX = x;
					c.mY = y;
				}
			}

		}

		public Cell[][] Cells
		{
			get
			{
				Cell[][] result = new Cell[mSize.Height][];

				// move from two dimension array to an array of arrays
				for (int y = 0; y < mSize.Height; y++)
				{
					Cell[] row = new Cell[mSize.Width];
					for (int x = 0; x < mSize.Width; x++)
					{
						row[x] = mCells[x, y];
					}
					result[y] = row;
				}
				return result;
			}
			set
			{
				// move from array of arrays to two dimensions array
				for (int y = 0; y < mSize.Height; y++)
				{
					for (int x = 0; x < mSize.Width; x++)
					{
						mCells[x, y] = value[y][x];
					}
				}
			}
		}
		
		public Size RedLinesModulo
		{
			get
			{
				return mRedLinesModulo;
			}
			set
			{
				mRedLinesModulo = value;
			}
		}
		

	}
}
