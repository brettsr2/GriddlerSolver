using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace hanjie
{
	public class colorRow
	{
		// we need to go fast
		// all member are public fields for speed
		// the precalculated fields are there only to make the search process faster

		public colorLine[] mLines;
		public int mLen; // precalc
		public Brain mBrain;
		public bool mIsRow;
		public int mRowIdx;
		public Int64 mComplexity;
		public bool mRowDone = false;
		public int mRowLength;
		public Cell[] mCells;
		public int mTotalColorCount;

		public colorRow(Brain brain, bool isRow, int rowIdx, int rowLength, IEnumerable Cells)
		{
			mBrain = brain;
			mIsRow = isRow;
			mRowIdx = rowIdx;
			mRowLength = rowLength;
			ArrayList l = new ArrayList();
			mTotalColorCount = 0;
			foreach (Cell c in Cells)
			{
				if (c.color > 0 && c.count > 0)
				{
					colorLine cs = new colorLine(this, c);
					mTotalColorCount += cs.count;
					l.Add(cs);
				}
			}
			mLines = (colorLine[])l.ToArray(typeof(colorLine));
			mLen = l.Count;

			for (int i = 0; i < mLen; i++)
			{
				colorLine cl = mLines[i];
				if (i > 0)
				{
					cl.prevLine = mLines[i - 1];
					cl.spaceBefore = (cl.prevLine.color == cl.color);
					cl.spaceAfter = false;
					cl.prevLine.spaceAfter = cl.spaceBefore;
					cl.absoluteMin = cl.prevLine.absoluteMin + cl.prevLine.count + (cl.spaceBefore ? 1 : 0);
				}
				else
				{
					cl.prevLine = null;
					cl.spaceBefore = false;
					cl.spaceAfter = false;
					cl.absoluteMin = 0;
				}

				if (i < (mLen - 1))
				{
					cl.nextLine = mLines[i + 1];
				}
				else
				{
					cl.nextLine = null;
				}
			}

			for (int i = mLen-1; i >=0; i--)
			{
				colorLine cl = mLines[i];
				if (i < mLen-1)
				{
					cl.absoluteMax = cl.nextLine.absoluteMax - cl.count - (cl.spaceAfter  ? 1 : 0);
				}
				else
				{
					cl.absoluteMax = cl.mRow.mRowLength - cl.count;
				}
			}

		}
	}
}
