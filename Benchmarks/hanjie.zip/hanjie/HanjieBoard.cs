using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Serialization;
using System.Runtime.Serialization;

namespace hanjie
{

	public partial class HanjieBoard : UserControl, ISupportInitialize
	{
		const Single ONE_THIRD = (Single)(1 / 3.0);
		const Single TWO_THIRD = (Single)(2 / 3.0);


		private Matrix mFixedRows;
		private Matrix mFixedCols;
		private Matrix mMainCells;

		private Single mZoom;
		private bool mInitializing;
		private bool mNeedRecalculateZoom;
		private int mNbColors;

		public delegate void cellClickedHandler(object sender, cellClickedEventArgs e);
		public event cellClickedHandler cellClicked;

		public HanjieBoard()
		{
			SetStyle(ControlStyles.AllPaintingInWmPaint, true);
			SetStyle(ControlStyles.OptimizedDoubleBuffer, true);
			SetStyle(ControlStyles.UserPaint, true);
			SetStyle(ControlStyles.ResizeRedraw, true);
			mFixedRows = new Matrix(MatrixLocation.fixedRows, this);
			mFixedCols = new Matrix(MatrixLocation.fixedCols, this);
			mMainCells = new Matrix(MatrixLocation.mainCells, this);
			InitializeComponent();

			mFixedCols.RedLinesModulo = new Size(mFixedRows.Width, 5);
			mFixedRows.RedLinesModulo = new Size(5, mFixedRows.Height);
			mMainCells.RedLinesModulo = new Size(5, 5);
			
		}

		public Size BoardSize
		{
			get
			{
				return mMainCells.Size;
			}
			set
			{
				mMainCells.Size = value;
				mFixedCols.Height = value.Height;
				mFixedRows.Width = value.Width;
			}
		}

		public int fixedRows
		{
			get
			{
				return mFixedRows.Height;
			}
			set
			{
				if (value != mFixedRows.Height)
				{
					mFixedRows.Height = value;
					NeedRecalculateZoom(true);
				}
			}
		}

		public int fixedCols
		{
			get
			{
				return mFixedCols.Width;
			}
			set
			{
				if (mFixedCols.Width != value)
				{
					mFixedCols.Width = value;
					NeedRecalculateZoom(true);
				}
			}
		}

		public int NbColors
		{
			get
			{
				return mNbColors;
			}
			set
			{
				mNbColors = value;
			}
		}

		protected override void OnMouseDown(MouseEventArgs e)
		{
			base.OnMouseDown(e);
			Cell c;
			Point pt = new Point(e.X, e.Y);
			c=mMainCells.PointToCell(pt);
			if (c==null) c=mFixedCols.PointToCell(pt);
			if (c==null) c=mFixedRows.PointToCell(pt);

			cellClickedEventArgs ev = new cellClickedEventArgs(c,pt);
			if (cellClicked != null) cellClicked(this, ev);
		}

		protected override void OnResize(EventArgs e)
		{
			base.OnResize(e);
			NeedRecalculateZoom(false);
		}

		internal void NeedRecalculateZoom(bool needRefresh)
		{
			if (mInitializing) mNeedRecalculateZoom = true;
			else RecalculateZoom(needRefresh);
		}

		void RecalculateZoom(bool needRefresh)
		{
			mNeedRecalculateZoom = false;

			Size RealSize = base.Size;
			// I add one cell width/height for borders
			//	1 third in the top
			//	1 third between the fixed row/cols and the main hanjieBoard
			//	1 third in the bottom
			SizeF lHanjieBoardSizeWithFixed = BoardSize + new Size(fixedCols + 1, fixedRows + 1);
			
			// look like it can live with div by 0
			PointF zoom = new PointF(
				RealSize.Width / lHanjieBoardSizeWithFixed.Width,
				RealSize.Height / lHanjieBoardSizeWithFixed.Height);

			PointF lOffset=PointF.Empty;

			if (zoom.X < zoom.Y)
			{
				mZoom = zoom.X;
				lOffset.X = mZoom * ONE_THIRD;
				lOffset.Y = (RealSize.Height - (lHanjieBoardSizeWithFixed.Height * mZoom)) / 2;
			}
			else
			{
				mZoom = zoom.Y;
				lOffset.X = (RealSize.Width - (lHanjieBoardSizeWithFixed.Width  * mZoom)) / 2;
				lOffset.Y = mZoom * ONE_THIRD;
			}

			lOffset.Y = (RealSize.Height - ((lHanjieBoardSizeWithFixed.Height - TWO_THIRD) * mZoom)) / 2;
			lOffset.X = (RealSize.Width - ((lHanjieBoardSizeWithFixed.Width - TWO_THIRD) * mZoom)) / 2;
			mMainCells.Org = new PointF(
					lOffset.X + (mZoom * (fixedCols + ONE_THIRD)),
					lOffset.Y + (mZoom * (fixedRows + ONE_THIRD)));

			mFixedCols.Org = new PointF(lOffset.X, mMainCells.Org.Y);
			mFixedRows.Org = new PointF(mMainCells.Org.X,lOffset.Y);

			// force a full redraw at some point
			if (needRefresh) Invalidate();
		}

		protected override void OnPaintBackground(PaintEventArgs e)
		{
			base.OnPaintBackground(e);
			// fixed rows
			mFixedRows.PaintBackGround(e.Graphics);
			mFixedCols.PaintBackGround(e.Graphics);
			mMainCells.PaintBackGround(e.Graphics);
		}

		public void SetZoom(double newZoom)
		{
			
			Size lSize;
			SizeF lHanjieBoardSizeWithFixed = BoardSize + new Size(fixedCols + 1, fixedRows + 1);
			lSize = new Size((int)(newZoom * lHanjieBoardSizeWithFixed.Width + 1), (int)(newZoom * lHanjieBoardSizeWithFixed.Height + 1));
			this.Size = lSize;
		}
		
		public Cell GetCell(MatrixLocation src, int x, int y)
		{
			switch (src)
			{
				case MatrixLocation.fixedCols: return mFixedCols.GetCell(x, y);
				case MatrixLocation.fixedRows: return mFixedRows.GetCell(x, y);
				case MatrixLocation.mainCells: return mMainCells.GetCell(x, y);
			}
			return null;
		}

		public Single zoom
		{
			get
			{
				return mZoom;
			}
		}

		#region ISupportInitialize Members

		void ISupportInitialize.BeginInit()
		{
			mInitializing = true;
		}

		void ISupportInitialize.EndInit()
		{
			mInitializing = false;
			if (mNeedRecalculateZoom) RecalculateZoom(true);
		}

		#endregion

		public void SaveTo(System.IO.Stream stream)
		{
			XmlSerializer xs = new XmlSerializer(typeof(SerializableBoard));
			SerializableBoard sb = new SerializableBoard();
			sb.FixedCols = mFixedCols;
			sb.FixedRows = mFixedRows;
			sb.MainCells = mMainCells;
			sb.NbColors = mNbColors;
			xs.Serialize(stream, sb);
		}

		public void LoadFrom(System.IO.Stream stream)
		{
			XmlSerializer xs = new XmlSerializer(typeof(SerializableBoard));
			SerializableBoard sb = (SerializableBoard)xs.Deserialize(stream);
			mFixedCols = FixAfterDeserialization(sb.FixedCols);
			mFixedRows = FixAfterDeserialization(sb.FixedRows);
			mMainCells = FixAfterDeserialization(sb.MainCells);
			mNbColors = sb.NbColors;
			NeedRecalculateZoom(true);
		}

		private Matrix FixAfterDeserialization(Matrix m)
		{
			m.mHanjieBoard = this;
			m.FixAfterDeserialization();
			return m;
		}

		// this class do not derive from Component and is therefore serializable without much effort
		public class SerializableBoard
		{
			public Matrix FixedCols;
			public Matrix FixedRows;
			public Matrix MainCells;
			public int NbColors;

			// XML Serialization needs an empty constructor
			public SerializableBoard()
			{
			}		
		}
	}

}
