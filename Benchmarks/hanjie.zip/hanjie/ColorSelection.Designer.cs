namespace hanjie
{
	partial class ColorSelection
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
			
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.HanjieBoard1 = new hanjie.HanjieBoard();
			((System.ComponentModel.ISupportInitialize)(this.HanjieBoard1)).BeginInit();
			this.SuspendLayout();
			// 
			// HanjieBoard1
			// 
			this.HanjieBoard1.BackColor = System.Drawing.Color.White;
			this.HanjieBoard1.BoardSize = new System.Drawing.Size(0, 0);
			this.HanjieBoard1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.HanjieBoard1.fixedCols = 0;
			this.HanjieBoard1.fixedRows = 0;
			this.HanjieBoard1.Location = new System.Drawing.Point(0, 0);
			this.HanjieBoard1.Name = "HanjieBoard1";
			this.HanjieBoard1.NbColors = 0;
			this.HanjieBoard1.Size = new System.Drawing.Size(32, 35);
			this.HanjieBoard1.TabIndex = 0;
			this.HanjieBoard1.cellClicked += new hanjie.HanjieBoard.cellClickedHandler(this.HanjieBoard1_cellClicked);
			// 
			// ColorSelection
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(42, 45);
			this.Controls.Add(this.HanjieBoard1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "ColorSelection";
			this.ShowInTaskbar = false;
			this.Text = "ColorSelection";
			this.Load += new System.EventHandler(this.ColorSelection_Load);
			((System.ComponentModel.ISupportInitialize)(this.HanjieBoard1)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private HanjieBoard HanjieBoard1;


	}
}