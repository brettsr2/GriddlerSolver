using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace hanjie
{
	
	public partial class ColorSelection : Form
	{
		public Cell SelectedCell;

		public ColorSelection(int nbColors, int nbMax)
		{
			InitializeComponent();
			this.HanjieBoard1.fixedCols = 1;
			this.HanjieBoard1.fixedRows = 1;
			this.HanjieBoard1.BoardSize = new Size(nbColors, nbMax);
			Cell cell;
			for (int x = 0; x < nbColors; x++)
			{
				cell = HanjieBoard1.GetCell(MatrixLocation.fixedRows, x, 0);
				cell.color = x;
				
				for (int y = 0; y < nbMax; y++)
				{
					cell = HanjieBoard1.GetCell(MatrixLocation.mainCells, x, y);
					cell.color = x;
					cell.count = y + 1;
				}
			}
			for (int y = 0; y < nbMax; y++)
			{
				cell = HanjieBoard1.GetCell(MatrixLocation.fixedCols, 0, y);
				//c.Count = y + 1;
			}
			HanjieBoard1.SetZoom(15);			
		}

		private void HanjieBoard1_cellClicked(object sender, cellClickedEventArgs e)
		{
			SelectedCell = e.cell;
			Close();
		}

		private void ColorSelection_Load(object sender, EventArgs e)
		{
			this.Size = HanjieBoard1.Size;
		}

	}
}