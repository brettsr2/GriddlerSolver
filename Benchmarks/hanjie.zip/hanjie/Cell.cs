using System;
using System.Collections.Generic;
using System.Drawing;
using System.Xml;
using System.Xml.Serialization;
using System.Runtime.Serialization;

namespace hanjie
{
	public class cellClickedEventArgs : EventArgs
	{
		private Cell mCell;
		private Point mMousePos;
		

		public Cell cell
		{
			get
			{
				return mCell;
			}
		}

		public Point MousePos
		{
			get
			{
				return mMousePos;
			}
		}

		public cellClickedEventArgs(Cell cell, Point mousePos)
		{
			mCell = cell;
			mMousePos = mousePos;
		}
	}

	public class Cell
	{
		protected internal int mColor;
		private int mCount;
		protected internal Matrix mMatrix;
		protected internal int mX, mY;
		
		public int color
		{
			get
			{
				return mColor;
			}
			set
			{
				mColor = value;
			}
		}

		public Color realColor
		{
			get
			{
				if (mColor == -1) return mMatrix.mHanjieBoard.BackColor;
				return realColors[mColor];
			}

		}

		Color[] realColors = new Color[16] {
			Color.White,
			Color.Black,
			Color.Green,
			Color.Blue,
			Color.Cyan,
			Color.Yellow,
			Color.Gray,
			Color.Purple,
			Color.Red,
			Color.Navy,
			Color.YellowGreen,
			Color.Turquoise,
			Color.SeaGreen,
			Color.SaddleBrown,
			Color.Salmon,
			Color.Pink};


		public int count
		{
			get
			{
				return mCount;
			}
			set
			{
				mCount = value;
			}
		}

		public Cell(Matrix matrix, int x, int y)
		{
			mMatrix = matrix;
			mX = x;
			mY = y;
		}

		public Point Location()
		{
			Single zoom = mMatrix.HanjieBoard.zoom;
			PointF pt = mMatrix.Org;
			return new Point((int)(pt.X + mX * zoom), (int)(pt.Y + mY * zoom));
		}

		public void SaveTo(XmlWriter xw)
		{
			xw.WriteElementString("Color", mColor.ToString());
			if (mCount > 0)
			{
				xw.WriteElementString("Val", mCount.ToString());
			}
		}

		public Cell()
		{
			// XML Serialization require an empty constructor
		}
	}
}
